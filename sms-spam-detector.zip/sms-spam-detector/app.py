!pip install streamlit

import streamlit as st
import pickle 